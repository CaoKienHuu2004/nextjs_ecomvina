export const APP_CONFIG = {
  API_BASE_URL: "http://148.230.100.215", // đổi domain sủa ở đây với code thuộc nhánh feartrure-new1 (Rin)
  API_ENDPOINTS: {
    TRANG_DIEU_KHOAN: "/api/trang-dieu-khoan",
    TRANG_GIOI_THIEU: "/api/trang-gioi-thieu",
    // Thêm các endpoint khác ở đây
    TRANG_LIEN_HE: "/api/trang-dieu-khoan",
        API_GUI_LIEN_HE: "/api/gui-lien-he",
  }
};