"use client";
import React from "react";
import Link from "next/link";
import Image from "next/image";

export default function FullFooter() {
  return (
    <>

      {/* bottom Footer */}

    </>
  );
}
