# Thư mục hình ảnh sản phẩm

Đây là thư mục chứa hình ảnh cho các sản phẩm. Vui lòng thêm các file ảnh vào đây với tên tương ứng:

- iphone-13-pro-max.jpg
- s22-ultra.jpg
- macbook-air-m2.jpg
- dell-xps-13.jpg
- airpods-pro-2.jpg
- sony-wh1000xm5.jpg
- galaxy-watch5-pro.jpg
- ipad-air-5.jpg

Yêu cầu ảnh:
- Định dạng: JPG hoặc PNG
- Kích thước khuyến nghị: 600x600px
- Dung lượng tối đa: 200KB/ảnh
